<?php
/**
 * Created by PhpStorm.
 * User: omardev
 * Date: 26/01/2018
 * Time: 12:54
 */


class Front_model extends CI_Model {


<<<<<<< HEAD
    public function send_view($data) {

        $query = $this->db->insert('customer_details',$data);
        return $query;
=======
    public function send_view() {


>>>>>>> 73f1ead0c708f2468416e063af6839e26b986394

    }



}