<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>NVS Insurance</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<<<<<<< HEAD
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
=======
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
>>>>>>> 73f1ead0c708f2468416e063af6839e26b986394
    <!-- Font Awesome -->
    <?php echo link_tag('assets/frontend/scss/nice-select.css')?>
    <?php echo link_tag('assets/frontend/css/style.css')?>
    <?php echo link_tag('assets/frontend/css/styles.css')?>
    <?php echo link_tag('assets/frontend/css/main.css')?>
<<<<<<< HEAD
    <?php echo link_tag('assets/frontend/css/header.css') ?>
    <?php echo link_tag('assets/frontend/css/fancy.css') ?>
    <?php echo link_tag('assets/frontend/css/responsive.css') ?>
    <?php echo link_tag('assets/frontend/css/animate.main.css') ?>
    <?php echo link_tag('assets/frontend/css/owl.carousel.min.css') ?>
    <?php echo link_tag('assets/frontend/css/bootsnav.css') ?>



=======
>>>>>>> 73f1ead0c708f2468416e063af6839e26b986394
</head>
<body>

    <!--Loading Pages -->
    <?php $this->load->view($main_view) ?>

<<<<<<< HEAD
    
     


=======
>>>>>>> 73f1ead0c708f2468416e063af6839e26b986394
    <!--Loading Pages -->
    <script
            src="https://code.jquery.com/jquery-3.2.1.min.js"
            integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
            crossorigin="anonymous"></script>
    <?php echo script_tag('assets/frontend/js/jquery.js')?>
<<<<<<< HEAD
    <?php echo script_tag('assets/frontend/js/active.js') ?>
=======
>>>>>>> 73f1ead0c708f2468416e063af6839e26b986394
    <?php echo script_tag('assets/frontend/js/jquery.nice-select.min.js')?>
    <?php echo script_tag('assets/frontend/js/fastclick.js')?>
    <?php echo script_tag('assets/frontend/js/prism.js')?>
    <?php echo script_tag('assets/frontend/js/index1.js')?>
<<<<<<< HEAD
    <?php echo script_tag('assets/frontend/js/index2.js')?>
    <?php echo script_tag('assets/frontend/js/bootsnav.js')?>
    <?php echo script_tag('assets/frontend/js/owl.carousel.min.js')?>
    <?php echo script_tag('assets/frontend/js/wow.min.js')?>
    <?php echo script_tag('assets/frontend/js/ajaxchimp.js')?>
    <?php echo script_tag('assets/frontend/js/ajaxchimp-config.js')?>
        <!--<?php echo script_tag('assets/frontend/js/jquery-2.2.4.min.js') ?>-->
    <?php echo script_tag('assets/frontend/js/popper.min.js') ?>
    <?php echo script_tag('assets/frontend/js/bootstrap.min.js') ?>
    <?php echo script_tag('assets/frontend/js/plugins.js') ?>
    <?php echo script_tag('assets/frontend/js/slick.min.js') ?>
    <?php echo script_tag('assets/frontend/js/footer-reveal.min.js') ?>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

=======
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
>>>>>>> 73f1ead0c708f2468416e063af6839e26b986394
    <?php echo script_tag('assets/frontend/js/script.js')?>

</body>

