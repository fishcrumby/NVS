<?php
/**
 * Created by PhpStorm.
 * User: omardev
 * Date: 26/01/2018
 * Time: 12:54
 */


class Front_model extends CI_Model {

    public function send_view($data) {

        $query = $this->db->insert('customer_details',$data);
        return $query;
    }
}