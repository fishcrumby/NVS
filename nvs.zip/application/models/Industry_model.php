<?php
/**
 * Created by PhpStorm.
 * User: omardev
 * Date: 23/01/2018
 * Time: 1:59
 */


class Industry_model extends CI_Model {


    public function get_industry() {

        $query = $this->db->get('industries');
        // return $query->result();
        return $query->num_rows();
    }

    public function get_industries_list() {

        $query = $this->db->get('industries');
        return $query->result();
    }

    public function create_industry($data) {
        $insert_data = $this->db->insert('industries', $data);
        return $insert_data;
    }
}