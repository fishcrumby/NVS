<?php
/**
 * Created by PhpStorm.
 * User: omardev
 * Date: 23/01/2018
 * Time: 2:27
 */


class Business extends CI_Controller {


    public function __construct()
    {
        parent::__construct();
    }


    public function create_administrative() {
        $this->form_validation->set_rules('business_name', 'Business Name', 'trim|required');

        if($this->form_validation->run() === FALSE) {
            $data = array(

                'errors' => validation_errors()
            );

            $this->session->set_flashdata($data);

            $data['main_view'] = "business/create_administrative";
            $this->load->view('templates/main', $data);
        } else {

            $data = array(
                'business_name'     => $this->input->post('business_name')
            );

            if($this->Business_model->create_administrative($data)) {

                $this->session->set_flashdata('created', 'New Business has been created');
                redirect('create_administrative');
            }
        }
    }

    /**
     * @return object
     */
    public function administrative() {

        $data['administrative'] = $this->Business_model->get_administrative_list();
        if(empty($data['administrative'])) {
            show_404();
        }

        $data['main_view'] = "business/administrative";
        $this->load->view('templates/main', $data);

    }


    public function accommodation() {

        $data['accommodation'] = $this->Business_model->get_accommodation();

        $data['main_view'] = "business/accommodation";
        $this->load->view('templates/main', $data);

    }


    public function retail() {

        $data['retail'] = $this->Business_model->get_retail();
        $data['main_view'] = "business/retail";
        $this->load->view('templates/main', $data);

    }

    public function contractor() {

        $data['contractor'] = $this->Business_model->get_contractor();
        $data['main_view'] = "business/contractor";
        $this->load->view('templates/main', $data);

    }

    public function estate() {

        $data['estate'] = $this->Business_model->get_estate();
        $data['main_view'] = "business/estate";
        $this->load->view('templates/main', $data);

    }

    public function event() {

        $data['event'] = $this->Business_model->get_event();
        $data['main_view'] = "business/event";
        $this->load->view('templates/main', $data);

    }
    public function manufacturer() {

        $data['manufacturer'] = $this->Business_model->get_manufacturer();
        $data['main_view'] = "business/manufacturer";
        $this->load->view('templates/main', $data);

    }
}