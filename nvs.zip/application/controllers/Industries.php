<?php
/**
 * Created by PhpStorm.
 * User: omardev
 * Date: 23/01/2018
 * Time: 1:44
 */


class Industries extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
    }


    public function view_industries() {

        $data['industries'] = $this->Industry_model->get_industries_list();

        if(empty($data["industries"])) {

            show_404();
        }
        
        $data['main_view']  = "industries/view_industries";
        $this->load->view('templates/main', $data);
    }

    public function create_industry() {
        $this->form_validation->set_rules('industry_name', 'Industry Name', 'trim|required');

        if($this->form_validation->run() === FALSE) {
            $data = array(

                'errors' => validation_errors()
            );

            $this->session->set_flashdata($data);

            $data['main_view'] = "industries/create_industry";
            $this->load->view('templates/main', $data);
        } else {

            $data = array(
                'industry_name'     => $this->input->post('industry_name')
            );

            if($this->Industry_model->create_industry($data)) {

                $this->session->set_flashdata('created', 'Industry has been created');
                redirect('create_industry');
            }
        }
    }

}