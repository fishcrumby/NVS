<?php
/**
 * Created by PhpStorm.
 * User: omardev
 * Date: 25/01/2018
 * Time: 2:48
 */


class Customers extends CI_Controller {

    public function view_customer() {

        $data['customers'] = $this->Customer_model->get_customers();
        $data['main_view'] = "pages/customer";
        $this->load->view('templates/main' , $data);
    }

    public function delete_customer($id = 1){

        if($this->Customer_model->delete_customer($id)) {

            $this->session->set_flashdata('deleted', 'Customer has been deleted');
            redirect('view_customer');
        }
    }
}