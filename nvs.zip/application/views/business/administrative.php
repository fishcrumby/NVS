<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>ADMINISTRATIVE SERVICES</h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url()?>home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="<?php echo base_url()?>industries">Industries Plan</a></li>
            <li class="active">Administrative Service</li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <!-- TABLE: LATEST ORDERS -->
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Administrative Service</h3>
                        <div class="box-tools pull-right">
                            <!-- <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                            </button>
                            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> -->
                            <a href="<?php echo base_url()?>create_administrative" class="btn btn-info pull-right"><i class="fa fa-plus"></i> Add Business</a>
                        </div>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <div class="table-responsive">
                            <table class="table no-margin">
                                <thead>
                                <tr>
                                    <th>Nature of Business Name</th>
                                    <th>Policies View</th>
                                    <th>Actions</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($administrative as $item):?>
                                    <tr>
                                        <td><?php echo $item->business_name; ?></td>
                                        <td><a href='<?php echo base_url()?>admin_policy1' class='label label-success'>View Plan One</a> <a href='<?php echo base_url()?>admin_policy2' class='label label-warning'>View Plan Two</a></td>
                                        <td><a href='<?php echo base_url()?>administrative' class='label label-primary'>View</a>
                                        <a href='<?php echo base_url();?>Policies/update_estate_policy1/<?php echo $item->id?>' class='label label-success'>Update</a>
                                        <a href='<?php echo base_url();?>Policies/update_estate_policy1/<?php echo $item->id?>' class='label label-success'>Edit</a>
                                        <a href='<?php echo base_url();?>Policies/delete_estate_policy1/<?php echo $item->id?>' class='label label-danger'>Delete</a></td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <!-- <tr>
                                        <td>Travel Agencies</td>
                                        <td><a href='<?php echo base_url()?>admin_policy1' class='label label-success'>View Plan One</a> <a href='<?php echo base_url()?>admin_policy2' class='label label-warning'>View Plan Two</a></td>
                                    </tr>
                                    <tr>
                                        <td>Architect Office</td>
                                        <td><a href='<?php echo base_url()?>admin_policy1' class='label label-success'>View Plan One</a> <a href='<?php echo base_url()?>admin_policy2' class='label label-warning'>View Plan Two</a></td>
                                    </tr>
                                    <tr>
                                        <td>Law Firms</td>
                                        <td><a href='<?php echo base_url()?>admin_policy1' class='label label-success'>View Plan One</a> <a href='<?php echo base_url()?>admin_policy2' class='label label-warning'>View Plan Two</a></td>
                                    </tr>
                                    <tr>
                                        <td>Accounting Firms</td>
                                        <td><a href='<?php echo base_url()?>admin_policy1' class='label label-success'>View Plan One</a> <a href='<?php echo base_url()?>admin_policy2' class='label label-warning'>View Plan Two</a></td>
                                    </tr> -->
                                </tbody>
                            </table>
                        </div>
                        <!-- /.table-responsive -->
                    </div>
                    <!-- /.box-body -->
                </div>
            </div>
    </section>
    <!-- /.content -->
</div>