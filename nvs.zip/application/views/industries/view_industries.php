<div class="content-wrapper">
    <!-- Content Header (Page header) -->

    <section class="content-header">
        <h1>INDUSTRIES PLAN</h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url()?>home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Industries Plan</li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <!-- TABLE: LATEST ORDERS -->
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Industries Plan</h3>
                        <div class="box-tools pull-right">
                            <!-- <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                            </button>
                            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> -->
                            <a href="<?php echo base_url()?>create_industry" class="btn btn-info pull-right"><i class="fa fa-plus"></i> Add New Industry</a>
                        </div>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <div class="table-responsive">
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr class="text-center">
                                    <th>Industry Name</th>
                                    <th>Actions</th>

                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach ($industries as $item):?>
                                    <tr>
                                        <td><?php echo $item->industry_name; ?></td>
                                        <td><a href='<?php echo base_url()?>administrative' class='label label-primary'>View</a>
                                        <a href='<?php echo base_url();?>Policies/update_estate_policy1/<?php echo $item->id?>' class='label label-success'>Update</a>
                                        <a href='<?php echo base_url();?>Policies/update_estate_policy1/<?php echo $item->id?>' class='label label-success'>Edit</a>
                                        <a href='<?php echo base_url();?>Policies/delete_estate_policy1/<?php echo $item->id?>' class='label label-danger'>Delete</a></td>
                                    </tr>
                                <?php endforeach; ?>

                                </tbody>
                            </table>

                            <!-- <table class="table no-margin">
                                <thead>
                                <tr>
                                    <th>Industry Name</th>
                                    <th>Nature of Business View</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>ADMINISTRATIVE SERVICE </td>
                                        <td><a href='<?php echo base_url()?>administrative' class='label label-primary'>View</a></td>

                                    </tr>
                                    <tr>
                                        <td>FOOD AND ACCOMONDATION</td>
                                        <td><a href='<?php echo base_url()?>accommodation' class='label label-primary'>View</a></td>

                                    </tr>
                                    <tr>
                                        <td>RETAIL</td>
                                        <td><a href='<?php echo base_url()?>retail' class='label label-primary'>View</a></td>

                                    </tr>
                                    <tr>
                                        <td>CONTRACTORS</td>
                                        <td><a href='<?php echo base_url()?>contractor' class='label label-primary'>View</a></td>

                                    </tr>
                                    <tr>
                                        <td>REAL ESTATE</td>
                                        <td><a href='<?php echo base_url()?>estate' class='label label-primary'>View</a></td>

                                    </tr>
                                    <tr>
                                        <td>EVENT MANAGEMENT INDUSTRY</td>
                                        <td><a href='<?php echo base_url()?>event' class='label label-primary'>View</a></td>

                                    </tr>
                                    <tr>
                                        <td>MANUFACTURERS</td>
                                        <td><a href='<?php echo base_url()?>manufacturer' class='label label-primary'>View</a></td>

                                    </tr>

                                </tbody>
                            </table> -->
                        </div>
                        <!-- /.table-responsive -->
                    </div>
                    <!-- /.box-body -->
                </div>
            </div>
    </section>

    <!-- /.content -->
</div>