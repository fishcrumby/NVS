<div class="content-wrapper">
    <section class="content-header">
        <h1>NEW INDUSTRY</h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url()?>home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="<?php echo base_url()?>industries">Industries Plan</a></li>
            <li class="active">Add New Industry</li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Add New Industry</h3>

                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <?php

                    $attr = array(

                        'role' => 'form'
                    )
                    ?>
                    <?php if($this->session->flashdata('errors')): ?>

                        <div class="alert alert-danger alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <h4><i class="icon fa fa-check"></i> Alert</h4>
                            <?php echo $this->session->flashdata('errors');?>
                        </div>
                    <?php endif; ?>
                    <?php if($this->session->flashdata('created')): ?>

                        <div class="alert alert-success alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <h4><i class="icon fa fa-check"></i> Alert</h4>
                            <?php echo $this->session->flashdata('created');?>
                        </div>
                    <?php endif; ?>

                    <?php echo form_open('Industries/create_industry',$attr)?>
                    <div class="box-body">

                        <?php

                        $data = array(
                            'class' => 'form-control',
                            'name' => 'industry_name',
                            'placeholder' => 'Enter Industry Name',
                            'value' => set_value('industry_name')
                        )
                        ?>
                        <?php echo form_label('Industry Name'); ?>
                        <?php echo form_input($data) ?>
                    </div>
                    <div class="box-body">
                        <?php

                        $data = array(
                            'class' => 'btn btn-success',
                            'id' => 'exampleInputText1',
                            'name' => 'created1',
                            'value' => 'Add New Industry'
                        )
                        ?>
                        <?php echo form_submit($data) ?>
                    </div>
                </div>
                <?php echo form_close();?>
            </div>
        </div>
    </section>
</div>